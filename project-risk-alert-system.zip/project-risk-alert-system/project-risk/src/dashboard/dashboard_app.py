import streamlit as st
import pandas as pd
import plotly.express as px

from src.processing.feature_engineering import build_feature_dataset
from src.models.predict import predict_risk
from src.alerts.alert_engine import generate_alerts

st.set_page_config(page_title="Project Risk Dashboard", layout="wide")
st.title("Project Risk Early Warning Dashboard")

base_df = build_feature_dataset()
pred_df = predict_risk(base_df)
alerts = generate_alerts()
alert_df = pd.DataFrame(alerts) if alerts else pd.DataFrame()

col1, col2, col3 = st.columns(3)
col1.metric("Total Projects Records", len(pred_df))
col2.metric("High/Critical Alerts", len(pred_df[pred_df["predicted_risk_level"].isin(["High", "Critical"])]))
col3.metric("Customer Escalations", int(pred_df["customer_escalation"].sum()))

st.subheader("Predicted Risk by Project")
fig = px.bar(
    pred_df,
    x="project_name",
    y="predicted_risk_probability",
    color="predicted_risk_level",
    hover_data=["project_manager", "practice", "week_id"]
)
st.plotly_chart(fig, use_container_width=True)

st.subheader("Cost Variance % vs Effort Variance %")
fig2 = px.scatter(
    pred_df,
    x="cost_variance_pct",
    y="effort_variance_pct",
    size="defect_count",
    color="predicted_risk_level",
    hover_data=["project_name", "project_manager", "practice"]
)
st.plotly_chart(fig2, use_container_width=True)

st.subheader("Detailed Prediction Table")
st.dataframe(pred_df[[
    "project_id",
    "project_name",
    "project_manager",
    "practice",
    "week_id",
    "cost_variance_pct",
    "effort_variance_pct",
    "schedule_variance_pct",
    "predicted_risk_probability",
    "predicted_risk_level"
]])

st.subheader("Generated Alerts")
if not alert_df.empty:
    st.dataframe(alert_df)
else:
    st.info("No alerts generated.")